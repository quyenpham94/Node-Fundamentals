/** Command-line tool to generate Markov text. */

